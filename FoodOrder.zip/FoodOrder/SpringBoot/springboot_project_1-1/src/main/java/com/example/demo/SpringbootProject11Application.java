package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProject11Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProject11Application.class, args);
	}

}
