import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AddcardRoutingModule } from './addcard-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AddcardRoutingModule
  ]
})
export class AddcardModule { }
