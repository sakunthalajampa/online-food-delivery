export class Product {
    
   product_id:number;
   product_name:String;
   product_price:number;
   product_total_price:number;

}