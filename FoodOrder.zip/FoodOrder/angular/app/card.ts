export class Card {
    
    card_id:number;
    card_user:String;
    card_email:String;
    card_phone:String;
    card_address:String;
    card_date_time:String;
    card_branch:String;
    card_user_name:String;
    card_new_number:String;
    card_expaire:String;
    card_cvv:String;

}